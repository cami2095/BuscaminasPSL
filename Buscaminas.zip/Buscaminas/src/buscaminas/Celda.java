
/*
 * @author Maria Camila Arias Puentes - 1030658053
 * @version 01
 */

package buscaminas;
//Importatciones directamente de Java para la ejecución correcta del programa
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import javax.swing.JButton;

/**
 *
 * @author Camila Arias
 */
public class Celda extends JButton {
//  Creación de las variables utilizadas en esta clase y en la clase de Ventana principal
   private int x;
   private int y;
   private int mina;
   private boolean visible;
   private Color colores[];
   
//Constructor 
   @SuppressWarnings("OverridableMethodCallInConstructor")
    public Celda(int x, int y) {
//        Inicialización de las variables 
        this.x = x;
        this.y = y;
        this.visible = false;
        this.colores= new Color[]{Color.BLUE,Color.GREEN,Color.RED,Color.YELLOW,Color.PINK,Color.ORANGE};
        this.setMinimumSize(new Dimension(33, 9));
        this.setBackground(new java.awt.Color(0, 0, 204));
        this.setFont(new java.awt.Font("Tahoma",1,12));
        this.addActionListener(new java.awt.event.ActionListener(){
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt){
            celdaActionPerformed(evt);
    }
    });
  }

    Celda() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    //Método celdaAction en donde se ejecuta el metodo click() y se determina si el usuario gano o perdio
            private void celdaActionPerformed(java.awt.event.ActionEvent evt) {
                click(); 
                 int contador =0;
                for (int i = 0; i < VentanaPrincipal.filas; i++) {
                    for (int j = 0; j < VentanaPrincipal.columnas; j++) {
                        if(VentanaPrincipal.celda[i][j].getVisible()){
                        contador++;
                        }
                        if(contador==(VentanaPrincipal.filas*VentanaPrincipal.columnas-VentanaPrincipal.minas)){
                            VentanaPrincipal.gano=true;
                        } 
                    }
                }

            }
// setters and getter de las variables necesarias 
    public int getMina() {
        return mina;
    }

    public void setMina(int mina) {
        this.mina = mina;
    }

    private boolean getVisible() {
      return visible;
    }
/*
    Este metodo es el encargado de determinar si una celda esta conformada por minas o por numeros o espacios en blanco
    la mina se determina por la imagen de la mina, el numero tiene un color especifico, el espacio en blanco es equivalente
    al - solicitado en el ejercicio.
    */
    private void click() {
        if(!visible && VentanaPrincipal.gano==false){
               this.visible=true;
               this.setBackground(new java.awt.Color(240,240,240));
               switch(this.mina){
                   case 0:
                       for (int i = 0; i < VentanaPrincipal.filas; i++) {
                           for (int j = 0; j < VentanaPrincipal.columnas; j++) {
                               if(VentanaPrincipal.celda[i][j].getMina()==0){
                             VentanaPrincipal.celda[i][j].setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/mina.png")));
                             VentanaPrincipal.celda[i][j].setBackground(new java.awt.Color(240,240,240));
                           }
                           }
                       }
                       VentanaPrincipal.gano=true;
               
                        break;
                   case 1:
                       int cont=0;
                       this.setBackground(new java.awt.Color(240,240,240));
                       for (int i = -1; i < 1; i++) {
                        if(x+i>=0&&x+i<VentanaPrincipal.filas) {
                            for (int j = -1; j < 1; j++) {
//                                System.out.println(y+i+" "+y+i+" "+VentanaPrincipal.columnas);
                                if((y+j>=0&&(y+j)<VentanaPrincipal.columnas)&&VentanaPrincipal.celda[x+i][y+j].getMina()==0){
                                cont++;
                            }
                           }
}                    
                       }
                       this.setText(""+cont);
                       this.setForeground(this.colores[cont]);
                       break;
                       
                   default:
                    for (int i = -1; i < 1; i++) {
                        if(x+i>=0&&x+i<VentanaPrincipal.filas) {
                            for (int j = -1; j < 1; j++) {
                                if((y+j>=0&&(y+j)<VentanaPrincipal.columnas)&&VentanaPrincipal.celda[x+i][y+j].getMina()!=0){
                                if(!VentanaPrincipal.celda[x+i][y+j].getVisible()){
                                    VentanaPrincipal.celda[x+i][y+j].click();
                                }
                            }
                           }
}                    
                       }
                           
                       }
                   
               }  
    }


}

        
      
   
   

